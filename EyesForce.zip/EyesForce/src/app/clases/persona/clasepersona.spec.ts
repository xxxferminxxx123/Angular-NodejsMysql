import { Clasepersona } from './clasepersona';

describe('Clasepersona', () => {
  it('should create an instance', () => {
    expect(new Clasepersona()).toBeTruthy();
  });
});
