export class Clasepersona {
}
