export class Clasecandidato {
}
