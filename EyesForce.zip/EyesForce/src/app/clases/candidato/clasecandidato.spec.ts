import { Clasecandidato } from './clasecandidato';

describe('Clasecandidato', () => {
  it('should create an instance', () => {
    expect(new Clasecandidato()).toBeTruthy();
  });
});
