import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snipper',
  templateUrl: './snipper.component.html',
  styleUrls: ['./snipper.component.css']
})
export class SnipperComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
