import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proceso-todos-candidatos',
  templateUrl: './proceso-todos-candidatos.component.html',
  styleUrls: ['./proceso-todos-candidatos.component.css']
})
export class ProcesoTodosCandidatosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
