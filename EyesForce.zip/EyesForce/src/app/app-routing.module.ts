import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CandidatosComponent } from './web/candidatos/candidatos.component';
import { HomeComponent } from './web/home/home.component'; 
import { PersonasComponent } from './web/personas/personas.component';
import { ProcesoTodosCandidatosComponent } from './web/proceso-todos-candidatos/proceso-todos-candidatos.component';



const routes: Routes = [
  {
    path:'',
    component:HomeComponent
  },
{
  path:'candidatos',
  component:CandidatosComponent
},
{
  path:'personas',
  component:PersonasComponent
},
{
  path:'proceso',
  component:ProcesoTodosCandidatosComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
