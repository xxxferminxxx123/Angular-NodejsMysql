import { Servicecandidato } from './servicecandidato';

describe('Servicecandidato', () => {
  it('should create an instance', () => {
    expect(new Servicecandidato()).toBeTruthy();
  });
});
