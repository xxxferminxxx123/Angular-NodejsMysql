export class Servicecandidato {
}
