import { Servicepersona } from './servicepersona';

describe('Servicepersona', () => {
  it('should create an instance', () => {
    expect(new Servicepersona()).toBeTruthy();
  });
});
