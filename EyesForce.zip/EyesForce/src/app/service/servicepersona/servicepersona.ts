export class Servicepersona {
}
